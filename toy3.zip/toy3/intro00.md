### Investment view

$\ B= A_{.1:k} .\Lambda_{1:k,1:k}^{.5}$       Loadings (3.3)  

$\ holding period = 2 . (long + short)/trade$

$\ performance = position . return = p.x = (\bar{p} + \tilde{p}) . (\bar{x} + \tilde{x})$

$\ \bar{p} . \bar{x}$ : 'Style Habitat Performance'

$\ \tilde{p} . \tilde{x}$ : 'Timing Performance'

$\ \bar{p} . \tilde{x}$ : 'Style Habitat Risk'

$\ \tilde{p} . \bar{x}$ : 'Timing Risk'

$\ performance(\tau)=position(t).return(t+\tau)$

$\ \tau<0$

$\ \tau=0$

$\ 0<\tau$

* On show: a simulated low-frequency contrarian global equity market neutral backtest, final year being 'walk-forward'

* The process has been used live at institutional scale, on the same investment universe analysed

* Universe: highly liquid large market capitalisation utilities in North America, Europe and Far East

* Strategies: four globally comparable alpha signals, all low-frequency contrarian
* Portfolio construction: mean-variance optimised with industry-neutrality constraints and bottom-up geographical tilts
* Application: the process was invested on this universe and successfully run out-of-sample for 1 year, 2.5<Sharpe 

### Navigation
The screen is split between a sidepanel and a set of tabbed panels, the entire page can be refreshed if required
Tour: the default setting is a 'tour' with progression either via 'next' or selecting the cases one at a time
Selecting 'freestyle' in the case dropdown reveals more detailed controls, whose values change in the tour

### Attribution view
Both portfolio construction and performance attribution make use of a statistical multi-factor model (PCA)
Risk components: the PCA model resolves market, other systematic, and stock-specific risk
Attribution: portfolio variables other than risk can be aggregated by weighted sum, then timeseries summarised
Timing: the weighted sum conveniently decomposes into low-frequency 'style habitat' and 'timing' components
Evolution: an 'event study' signature reveals the behaviour captured before and after portfolio construction
Costs: each aspect of the attribution provides insight into trade urgency, transaction and finance costs

### Data and technology
SQL : raw data, risk models, optimised portfolios are stored in relational database
R : the R data language provides statistical functions and 'glue' role
data.table : fast in-memory database-type operations 
Googlevis API : visualisation via Javascript libraries hosted by Google
Rstudio shiny : delivers the interactivity html5, javascript and Twitter Bootstrap

### On offer
Investment process: the process illustrated had high performance in out-of-sample testing at a leading hedge fund
Integration: all data is acquired via Bloomberg API and can be fed back to Bloomberg PORT for monitoring and trading
Analytical framework: the framework shown can be applied to backtests on any signal on any universe
Custom analytics and extensions using the same and related technologies centred around R analytics
Contact the designer, author, and implementor of all aspects of this product for an on-site demo
