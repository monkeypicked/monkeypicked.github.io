#### timing
Timing identifies performance atributable to static and dynamic components of premium and position

Units are decimal (multiply by 100 for %)
* performance = return . position = x . p
    * pe = [mean(x) + dev(x)] . [mean(p) + dev(p)] = pbxb + pbxt + ptxb +ptxt


 $\frac{1}{n} \sum_{i=1}^{n} x_{i}$ 
 
 \( P(E) = {n \choose k} p^k (1-p)^{n-k} \) 

$\ B= A_{.1:k} .\Lambda_{1:k,1:k}^{.5}$       Loadings (3.3)  


    * pbxb : 'STYLE HABITAT PERFORMANCE'
    * ptxt : 'TIMING PERFORMANCE'
    * pbxt : 'STYLE HABITAT RISK'
    * ptxb : 'TIMING RISK'
* the 'cross-terms' pbxt and ptxb only contribute to volatility, not to mean performance
* for a profitable after-costs strategy
    * transactions costs < timing performance
    * finance costs < style habitat performance
* example: strategy performance
    * select *timing* in the case dropdown
    * select *LStot* in the y-picker of the graphic
    * note pbxb and ptxt contribute positively and similar amounts 
    * select *LSres* and then *LSsys* and note respective contributions
* example: universe performance
    * select model=universe in sidebar dropdown
    * select each component in turn in the y-picker
    * universe (all-long) performance attributes to static market performance
* this attribution can be generalised
    * all panels are attributed in this way, not just performance
    * the static analysis here are a special case of rolling
    * parameters are all stored under class *ba*
    * this is a special case of a more general frequency analysis
