$\ \bar{p} . \bar{x}$
