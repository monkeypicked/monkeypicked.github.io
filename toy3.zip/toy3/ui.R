library(shiny)
shinyUI(pageWithSidebar(
  headerPanel("Archives"),
  sidebarPanel(
    selectInput(inputId="testselect1",label="letters",choices=1:26),
    selectInput(inputId="testselect2",label="letters",choices=LETTERS),
    selectInput(inputId="setter",label="lettersetter",choices=LETTERS),
    actionButton(inputId="doset",label="set the letter!"),
    checkboxInput(inputId='check1',label="check1"),
    conditionalPanel(condition="TRUE",includeMarkdown("4.md")),
    includeHTML("1eq.html")
  ),  
  mainPanel(
     tabsetPanel(id="x1",
      tabPanel("x3")       
    )
  )
))