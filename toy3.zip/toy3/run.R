require(shiny)
require(data.table)
runApp("c:/users/giles/repo/shiny/toy/")